import java.awt.Graphics;

public class Tile {
	private boolean isAMine, beenClicked, flagged;
	private int numMinesAround;
	
	
	public void draw(Graphics g) {
		
	}
	
	
}
