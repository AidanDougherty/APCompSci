import javax.swing.JOptionPane;

import kareltherobot.World;
import java.util.ArrayList;


public class SortRobotDriver {
int arraySize;
int numBots;
int maxBeeps;
int minBeepsInSet;
int maxBeepsInSet;
SortableRobot minBeepsRobot;
SortableRobot maxBeepsRobot;
//ArrayList<SortableRobot> minBots =new ArrayList<SortableRobot>();
ArrayList<SortableRobot> bots = new ArrayList<SortableRobot>();


	public static void main(String[] args) {
		new SortRobotDriver().start();
	}

	private void start() {
		//1. input number of robots, and max number of beepers
		//2. create that number of robots (from part 1) with max number
		// of beeps, and place into an array and return that array to here.
		//3. Find robot with min # of beeps. Have that bot show all beeps
		//4. Repeat looking for max # of beeps.
		
		
		//Now sort 
		//A.  BubbleSort
		//B.  SelectionSort
		//C.  InsertionSort
		//D.  QuickSort
		//E.  MergeSort
		String numberBots = JOptionPane.showInputDialog("input number of robots:");
		numBots = Integer.parseInt(numberBots);
		String numberBeeps = JOptionPane.showInputDialog("input max beepers:");
		maxBeeps = Integer.parseInt(numberBeeps);
		World.setSize( maxBeeps+4,numBots+4 );
		World.setDelay(1);
		World.setVisible(true);
		makeBots(numBots, maxBeeps);
		showMeTheBeeps(numBots);
		dontShowMeTheBeeps(numBots);
		getMin().showAllBeeps();
		JOptionPane.showConfirmDialog(null, "min beeps is: "+minBeepsInSet);
		minBeepsRobot.pickUpAllBeeps();
		getMax().showAllBeeps();
		JOptionPane.showConfirmDialog(null, "max beeps is: "+maxBeepsInSet);
		maxBeepsRobot.pickUpAllBeeps();
		//mySort();
		bubbleSort();
		showMeTheBeeps(numBots);
		//swapBots(bots.get(0),bots.get(3));
		//System.out.println(bots.get(0).getNumBeeps());
		//int[]loc={7,5};
		//bots[numBots-1].moveToLocation(loc);
		
		
		
		
		
		
		
		
	}
	private void showMeTheBeeps(int numBots){
		for (int c=0;c<numBots;c++){
			bots.get(c).showAllBeeps();
		}
	}
	private void dontShowMeTheBeeps(int numBots){
		for(int c=0;c<numBots;c++){
			bots.get(c).pickUpAllBeeps();
			
		}
	}
	private SortableRobot getMin(){
		minBeepsRobot=bots.get(0);
		for (int c=0;c<numBots;c++){
			if (bots.get(c).getNumBeeps()<minBeepsRobot.getNumBeeps()){
				minBeepsRobot=bots.get(c);
				
			}
			//System.out.println(c);
		}
		minBeepsInSet = minBeepsRobot.getNumBeeps();
		
		
		return minBeepsRobot;
	}
	private SortableRobot getMax(){
		maxBeepsRobot=bots.get(0);
		for (int c=0;c<numBots;c++){
			if (bots.get(c).getNumBeeps()>maxBeepsRobot.getNumBeeps()){
				maxBeepsRobot=bots.get(c);
			}
			//System.out.println(c);
		}
		maxBeepsInSet = maxBeepsRobot.getNumBeeps();
		
		return maxBeepsRobot;
	}
	private void mySort(){
		for(int c=0; c<numBots; c++){
			for (int d=0;d<numBots; d++){
				if(bots.get(c).getNumBeeps()<bots.get(d).getNumBeeps()){
					swapBots(bots.get(c),bots.get(d));
					SortableRobot temp=bots.get(c);
					bots.set(c, bots.get(d));
					bots.set(d, temp);
				}
			}
		}
	}
	private void selectionSort(){
		ArrayList<SortableRobot> tempBots = new ArrayList<SortableRobot>();
		getMin();
	}
	private void bubbleSort(){
		for (int times = 0; times<numBots-1;times++){
			for (int c=0; c+1<numBots-times;c++){
				if(bots.get(c).getNumBeeps()>bots.get(c+1).getNumBeeps()){
					swapBots(bots.get(c),bots.get(c+1));
					SortableRobot temp = bots.get(c);
					bots.set(c, bots.get(c+1));
					bots.set(c+1, temp);
					
				}
			}
		}
	}
	
	private void swapBots(SortableRobot r, SortableRobot r1){
		int[] rloc=r.getLocation();
		
		r.moveToLocation(r1.getLocation());
		r1.moveToLocation(rloc);
		
	}
	private void makeBots(int numBots, int maxBeeps){
		for (int c=0;c<numBots;c++){
			
			bots.add(c,new SortableRobot(1,c+1,(int)(Math.random()*maxBeeps)));
			
			
		}
	}

}
