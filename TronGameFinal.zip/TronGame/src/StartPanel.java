import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class StartPanel extends JPanel{

	private boolean running;
	public static int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height - 100;
	public static int screenLength = Toolkit.getDefaultToolkit().getScreenSize().width-20;
	private static ArrayList<BufferedImage> images = new ArrayList<BufferedImage>();
	private JButton[] buttons= new JButton[2];
	private static BufferedImage logo;

	public StartPanel(){
		openImages();
		for(int a=0; a<2; a++) {
		if(a==0)
			buttons[a]= new JButton("local");
			else
				buttons[a]= new JButton("online");
		this.setLayout(null);
		buttons[a].setBounds(screenLength/4,screenHeight/6+screenHeight/2*a, screenLength/2, screenHeight/8);
		buttons[a].setFont(new Font(Font.SANS_SERIF, Font.ROMAN_BASELINE, 30));
		//b.setIcon(new ImageIcon(images.get(1)));
		this.add(buttons[a]);
		}
		buttons[0].addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				localGame();
			
			}
		});
		buttons[1].addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				multiGame();
			
			}
		});
	}
	protected void multiGame() {
		// TODO Auto-generated method stub
		TronPanel.isMulti=true;
		for(int a=0; a<2; a++) {
			String s="join";
			if(a==0)
				s="host";
			buttons[a].setText(s);
			buttons[a].removeActionListener(buttons[a].getActionListeners()[0]);
			this.add(buttons[a]);
		}
		buttons[0].addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//TronPanel.isHost=true;
				TronPanel.nextPanel4();
			}
		});
		buttons[1].addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				TronPanel.isHost=false;
				//Client.IP=JOptionPane.showInputDialog("Please enter the IP Address of the server");
				TronPanel.nextPanel5();
				
			}
		});
		
	}
	protected void localGame() {
		// TODO Auto-generated method stub
		TronPanel.isMulti=false;
		for(int a=0; a<2; a++) {
			String s="multiplayer";
			if(a==0)
				s="singleplayer";
			buttons[a].setText(s);
			buttons[a].removeActionListener(buttons[a].getActionListeners()[0]);
			this.add(buttons[a]);
			
		}
		buttons[0].addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				TronPanel.is2PlayerLocal=false;
				inputAI();
			}
		});
		buttons[1].addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				TronPanel.is2PlayerLocal=true;
				inputAI();
			}
		});
	}
	private void inputAI() {
		//TronPanel.numAI=Integer.parseInt(JOptionPane.showInputDialog("How many AI?"));
		//TronPanel.nextPanel();
		// TODO Auto-generated method stub
		TronPanel.numAI=Integer.parseInt(JOptionPane.showInputDialog("How many AI?"));
		TronPanel.nextPanel6();
		
	}
	private void openImages() {
//		// TODO Auto-generated method stub
//		try {
//			images.add(ImageIO.read(new File("tronLogo.png")));
//			//images.add(ImageIO.read(new File("startLogo.png")));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		try {
			images.add(ImageIO.read(new File("tronLogo.png")));
			//images.add(ImageIO.read(new File("startLogo.png")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean isRunning(){
		return running;
		
	}
	public void paintComponent(Graphics g) {
		
		g.drawImage(images.get(0), 0, 0, screenLength, screenHeight, null);
		
	}
}
