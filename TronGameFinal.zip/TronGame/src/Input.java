import java.io.*;
public class Input implements Runnable{
	
	DataInputStream in;
	Client c;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public Input(DataInputStream in, Client c){
		this.in = in;
		this.c = c;
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			String msg;
			try {
				msg = in.readUTF();
				System.out.println("RECIEVED: "+msg);
				TronPanel.print(msg);
				String ip = msg.substring(0, msg.indexOf(":"));
				String action = msg.substring(msg.indexOf(":")+1);
				if(!action.equals("B")&&!action.equals("RESTART")){
				TronPanel.moveTron(ip,action);
				//TronPanelClient.moveTron(ip, action);
				}
				else if(action.equals("RESTART")){
					TronPanel.restart();
					//TronPanelClient.restart();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
