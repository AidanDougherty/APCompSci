import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class HostPanel extends JPanel{

	private JButton startGame;
	
	
	public HostPanel(){
		startGame = new JButton("Start Game");
//		enterIP = new JTextField("Enter IP Here");
//		enterIP.setHorizontalAlignment(JTextField.LEFT);
//		enterIP.setBounds(1260/4,700/4, 1260/2, 700/8);
		TronPanel.makeServer();
		TronPanel.hostConnect();
		startGame.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//System.out.println("boop");
				
				TronPanel.nextPanel2();
				
			
			}
		});
		this.setLayout(null);
		startGame.setBounds(1260/4,700/3, 1260/2, 700/8);
		startGame.setBackground(Color.BLACK);
		startGame.setFont(new Font(Font.SANS_SERIF, Font.ROMAN_BASELINE, 30));
		this.add(startGame);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame("test");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		HostPanel p = new HostPanel();
		p.setPreferredSize(new Dimension(1260,700));
		frame.add(p);
		//frame.setSize(1260, 700);
		frame.setBackground(Color.BLACK);
		frame.pack();
		frame.setVisible(true);
	}
	public void paintComponent(Graphics g) {
		
		g.setColor(Color.WHITE);
		g.drawString("Waiting for Guest", 1260/4, 700/4);
		
	}

}
