import java.io.*;
public class User implements Runnable{
	DataOutputStream out;
	DataInputStream in;
	User[] users;
	
	public User(DataOutputStream out, DataInputStream in, User[] users){
		this.users = users;
		this.out = out;
		this.in = in;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			try {
				String msg = in.readUTF();
				for(int i = 0; i<users.length;i++){
					if(users[i]!=null){
						users[i].out.writeUTF(msg);
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
