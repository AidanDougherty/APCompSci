public class AI {
	private int dif;
	private boolean turnLeft;
	private boolean turnRight;

	public AI(int diff) {
		setDif(diff);
		turnLeft = false;
		turnRight = false;
	}

	public Tron.Direction getMove(int[] is, Tron.Direction dir) {
		// TODO Auto-generated method stub
		int first = is[0];
		int second = is[1];

		int a = TronPanel.distinfront(new int[] { first, second }, dir);
		int b = TronPanel.distinfront(new int[] { first, second }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
		int c = TronPanel.distinfront(new int[] { first, second }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
		Tron.Direction dire = TronPanel.distToOthers(new int[] { first, second }, dir);
		Tron.Direction dire2 = TronPanel.farDistToOthers(new int[] { first, second }, dir);
		Tron.Direction dire3 = TronPanel.checkDeadEnd(new int[] { first, second }, dir);

		if (getDif() == 1) {

			if (a > 0) {
				return dir;
			} else {
				if (b > c) {
					return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
				} else {

					return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
				}

			}
		}

		else if (getDif() == 2) {

			if (a > b && a > c) {
				return dir;
			} else {
				if (b > c) {
					return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
				} else {

					return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
				}

			}

		} else if (getDif() == 3) {
			return dire2;
		} else if (getDif() == 4 || getDif() == 5 || getDif() == 6) {
			return dire3;
		}
			return dir;
	}

	public int getDif() {
		return dif;
	}

	public void setDif(int dif) {
		this.dif = dif;
	}
	
	

}
