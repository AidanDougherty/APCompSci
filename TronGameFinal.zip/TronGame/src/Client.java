import java.net.*;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.Timer;

public class Client implements Runnable{
	static Socket socket;
	static DataInputStream in;
	static DataOutputStream out;
	boolean online;
	static Timer t;
	static String msg;
	static String inMsg;
	boolean canWrite;
	static boolean connected;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//t = new Timer(50,null);
		new Client(null).start();


	}

	public Client(String s) throws Exception{
		System.out.println("Connecting...");
		//192.168.1.20
		//73.92.125.28
		//48042
		
		socket = new Socket(s,48042);
			
		//canWrite = true;
		connected = true;
		online = true;
		msg = "";
		System.out.println("Connected");
		in = new DataInputStream(socket.getInputStream());
		out = new DataOutputStream(socket.getOutputStream());
		Input input = new Input(in, this);
		
		Thread thread = new Thread(input);
		TronPanel.print("made input");
		thread.start();
	}
	
	private void write(String s) throws Exception{
		try{
			out.writeUTF(s);
			System.out.println("wrote msg: "+s);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void start() throws Exception{
		// TODO Auto-generated method stub
		System.out.println("Connecting...");
		//192.168.1.20
		//73.92.125.28
		//48042
		
		socket = new Socket("localhost",48042);
			
		
		connected = true;
		online = true;
		msg = "";
		System.out.println("Connected");
		in = new DataInputStream(socket.getInputStream());
		out = new DataOutputStream(socket.getOutputStream());
		Input input = new Input(in, this);
		Thread thread = new Thread(input);
		thread.start();

		while(online){

			//			String msg = in.readUTF();
			//			if(msg.equals("SYSTEM.EXIT")){
			//				online = false;
			//			}else{
			//System.out.println("SER: "+msg);

			if(canWrite){
				out.writeUTF(msg);
				canWrite = false;
			}
			//System.out.println("CL: "+s);
		}

	}

	public void setActionMessage(String s){
		if(connected){
			msg = socket.getLocalAddress().toString() + ":"+s;
			//System.out.println("set Action to: "+msg);
			TronPanel.print("set Action to:"+msg);
			canWrite = true;
			//System.out.println(canWrite);
			try {
				write(msg);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public String getIP(){
		return socket.getLocalAddress().toString();
	}

	@Override
	public void run(){
		// TODO Auto-generated method stub
//		while(online){
//
//			//			String msg = in.readUTF();
//			//			if(msg.equals("SYSTEM.EXIT")){
//			//				online = false;
//			//			}else{
//			//System.out.println("SER: "+msg);
//			//System.out.println("Client running");
//
//			if(canWrite){
//				try {
//					out.writeUTF(msg);
//					System.out.println("wrote msg: "+msg);
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				canWrite = false;
//			}
//			//System.out.println("CL: "+s);
//		}
	}




	//}
	//	protected static void tick(){
	//		try {
	//			//System.out.println("tick");
	//			msg = in.readUTF();
	//			if(msg!=null)
	//			System.out.println("SER: "+msg);
	//			
	//			
	//		} catch (IOException e) {
	//			// TODO Auto-generated catch block
	//			//e.printStackTrace();
	//		}
	//		
	//	}


}
