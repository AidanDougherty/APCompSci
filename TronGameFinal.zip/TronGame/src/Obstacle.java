import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;



public class Obstacle extends Tron{


	private int size = TronPanel.getW();
	private int lvl = 1, screenHeight, screenLength; 

	public Obstacle(int x, int y, Direction dir, int screenHeight, int screenLength) {
		super(x, y, dir, 0);
		super.setDone(true);
		super.setObstacle(true);
		// TODO Auto-generated constructor stub
		this.screenHeight = screenHeight;
		this.screenLength = screenLength;
		segments();
	}

	public void move() {
	}
	public void restart() {
	}

	public void draw(Graphics g) {
		//code for segment add
		g.setColor(Color.ORANGE);
		for (Segment seg : s) {
			g.fillRect(seg.getX(), seg.getY(), size, size);
		}
		g.setColor(Color.orange);
	}
	//switch(lvl) {
	//	
	//	case 1: //level1(g);
	//			break;
	//	case 2: level2(g);
	//			break;
	//	case 3: level3(g);
	//			break;
	//	case 4: level4(g);
	//			break;
	//	case 5: level5(g);
	//			break;
	//	case 6: level6(g);
	//			break;
	//	case 7: level7(g);
	//			break;
	//}
	//
	//	
	//	
	//
	//
	//	private void level7(Graphics g) {
	//		// TODO Auto-generated method stub
	//		
	//	}
	//
	//
	//	private void level6(Graphics g) {
	//		// TODO Auto-generated method stub
	//		
	//	}
	//
	//
	//	private void level5(Graphics g) {
	//		// TODO Auto-generated method stub
	//		
	//	}
	//
	//
	//	private void level4(Graphics g) {
	//		// TODO Auto-generated method stub
	//		
	//	}
	//
	//
	//	private void level3(Graphics g) {
	//		// TODO Auto-generated method stub
	//		
	//	}
	//
	//
	//	private void level2(Graphics g) {
	//		// TODO Auto-generated method stub
	//		
	//		for(Segment s : s) {g.drawRect(s.getX(), s.getY(), size, size); }
	//
	//	
	//	}
	//

	public void segments() {
		s.clear();
		switch(lvl) {

		case 1: //level1(g);
			break;
		case 2: level2seg();
		break;
		case 3: level3seg();
		break;
		case 4: level4seg();
		break;
		case 5: level5seg();
		break;
		case 6: level6seg();
		break;
		case 7: level7seg();
		break;
		}
	}

	private void level7seg() {
		// TODO Auto-generated method stub

	}


	private void level6seg() {
		// TODO Auto-generated method stub
		int x=screenLength;
		int y = 0;
		for(;x < screenHeight; x+=2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
		y = 0;
		for(;x < screenLength; x-=2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
	}


	private void level5seg() {
		// TODO Auto-generated method stub
		int x=screenHeight;
		int y = 0;
		for(;x < screenHeight; x=-2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
		y = 0;
		for(;x < screenLength; x+=2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
	}


	private void level4seg() {
		// TODO Auto-generated method stub
		int x=0;
		int y = 0;
		for(;x < screenHeight; x+=2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
		y = 0;
		for(;x < screenLength; x+=2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
	}


	private void level3seg() {
		// TODO Auto-generated method stub
		int y = 0;
		for(int x = 0; x < screenHeight; x+=2*size) { 
			s.add(new Segment(x, y));
			y += 2*size;
		}
	}


	private void level2seg() {
		// TODO Auto-generated method stud
		int y = 0;
		for(int x = 0; x < screenHeight; x+=size) { 
			s.add(new Segment(x, y));
			y += size;
		}
		//for(int x = 900; x < 2000; x++) 
		//s.add(new Segment(x, 500)); 
	}


	public int incLevel() { lvl++; lvl%=7; segments(); return lvl; }

}

