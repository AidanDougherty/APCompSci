
import java.awt.Color;
import java.awt.Graphics;

public class Board {
	public Board() {
	}

	public void draw(Graphics g) {
		int dif = TronPanel.screenHeight/20;
		//NEW code, adjust colors as you'd like
		for(int a = 0; a<20; a++) {
			int c = 255;
			for(int b = 0; b<20; b++) {
				g.setColor(new Color(c, 0, 255-c));
				g.drawRect(b*dif, a*dif, (b+1)*dif, 1);
				c-=255/20;
			}
		}
		dif = TronPanel.screenLength/40;
		for(int a = 0; a<20; a++) {
			int c = 255;
			for(int b = 0; b<40; b++) {
				g.setColor(new Color(c, 0, 255-c));
				g.drawRect(b*dif, a*dif, 1, (b+1)*dif);
				c-=255/40;
			}
		}
		
		//old code
/*		
		for (int i = 0; i < 20; i ++) { // amount of lines
			System.out.println(i);
			int[] color = { 250, 0 };
			for (int r = 0; r < 40; r++) {
				
				g.setColor(new Color(color[0], 0, color[1]));
				g.drawLine(r, i, r + dif, i);
				System.out.println(color[0]);
				color[0] -= colorDivideHeight;
				System.out.println(color[1]);
				color[1] += colorDivideHeight;

			}
		}

		int difL = screenLength / 40;
		for (int r = 0; r < 40; r ++) { // amount of lines
			int[] color = { 250, 0 };
			for (int c = 0; c < screenHeight; c += difL) {
				g.setColor(new Color(color[0], 0, color[1]));
				g.drawLine(r, c, r, c + difL);
				color[0] -= colorDivideLength;
				color[1] += colorDivideLength;
			}
		}
*/
	}
	
}
