
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import javax.swing.UIManager;



public class TronPanel extends JPanel {

	public static int screenHeight = 700/*Toolkit.getDefaultToolkit().getScreenSize().height - 100*/;
	public static int screenLength = 1260/*Toolkit.getDefaultToolkit().getScreenSize().width-20*/;
	private static Board board = new Board();

	private static ArrayList<Tron> tronList = new ArrayList<Tron>();

	public static JFrame frame;
	private static int w=10;
	private static int t=50;
	private static Timer timer = new Timer(t, null);
	public static TronPanel sp = new TronPanel();
	public static StartPanel p;
	public static HostPanel hp;
	public static ClientPanel cp;
	public static boolean isMulti;
	public static boolean is2PlayerLocal;
	public static boolean isHost;
	public static int numAI;
	private static JLabel label; 
	public static boolean serverMade;
	private static Server ser;
	private static Client self;
	private static Obstacle obstacle = new Obstacle(0,0, Tron.Direction.N, screenHeight, screenLength);
	private boolean random;
	


	public static void main(String[] args) {
		
//		tronList.add(new Tron(screenLength/2+180, 300, Tron.Direction.E, 0));
//		tronList.add(new Tron(screenLength/2, 500, Tron.Direction.S, 0));
		//tronList.add(new Tron(screenLength/2-180, 300, Tron.Direction.W, 0));
		//tronList.add(new Tron(screenLength/2, 100, Tron.Direction.N, (int) (Math.random()*2+1)));
		try {
			// Set System L&F
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		frame = new JFrame("Tron!");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p = new StartPanel();
		
		//hp = new HostPanel();
		//cp = new ClientPanel();
		frame.add(p);
		p.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.setBackground(Color.BLACK);
		frame.pack();
		frame.setVisible(true);

		//while(p.isRunning()){
		//System.out.println("plz");
		//System.out.println("bob "+p.isRunning());
		//}


	}
	public static void hostConnect(){
		tronList.add(new Tron(screenLength/2+180, 300, Tron.Direction.E, 0));
		tronList.add(new Tron(screenLength/2, 500, Tron.Direction.S, 0));
		try {
			//System.out.println(InetAddress.getLocalHost().getHostAddress());
			self = new Client("localhost");
			Thread selfThread = new Thread(self);
			selfThread.start();
			//10.141.47.209 - Danial's ip
			//****temporary, need to have server send client ip here
			tronList.get(1).setIP("/10.141.47.209");
			///10.141.131.237
			tronList.get(0).setIP(self.getIP());
			//tronList.get(2).setIP("/10.141.44.140");
			System.out.println("connected");
			sp.setUpMultiKeyMappings();
			
		//Client.main(null);
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public static void clientConnect(String s){
		tronList.add(new Tron(screenLength/2+180, 300, Tron.Direction.E, 0));
		tronList.add(new Tron(screenLength/2, 500, Tron.Direction.S, 0));
		try {
			
				self = new Client(s);
				Thread selfThread = new Thread(self);
				selfThread.start();
				tronList.get(1).setIP(self.getIP());
				///10.141.131.237
				tronList.get(0).setIP("/127.0.0.1");
				//tronList.get(2).setIP("/10.141.44.140");
				System.out.println("connected");
				sp.setUpMultiKeyMappings();
				
			//Client.main(null);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void makeServer(){
		isHost = true;
			try {
				//System.out.println("making connect");
				//Server.main(null);
				ser = new Server();
				Thread serThread = new Thread(ser);
				serThread.start();
				System.out.println("Made server");
				serverMade = true;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
	}
	
	private void addCycles() {
		// TODO Auto-generated method stub
		tronList.add(0,new Tron(screenLength/2+10*w+10, 300, Tron.Direction.W, 0));
		if(is2PlayerLocal)
			tronList.add(new Tron(screenLength/2-w+10, 500, Tron.Direction.N, 0));
		if(numAI>0)
			tronList.add(new Tron(screenLength/2-10*w+10, 300-w, Tron.Direction.E, 1));
		if(numAI>1)
			tronList.add(new Tron(screenLength/2+10, 100, Tron.Direction.S, 1));
		if(!is2PlayerLocal&& numAI>2)
			tronList.add(new Tron(screenLength/2-w+10, 500, Tron.Direction.N, 1));
		tronList.add(obstacle); 
		//lvl = new Level(obstacle); 
	}
	
	public static void nextPanel(String s){
		frame.remove(p);
		frame.add(sp);
		sp.setBackground(Color.BLACK);
		sp.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.pack();
		frame.setVisible(true);
		isMulti = true;
		isHost = true;
		if(!isMulti){
			sp.setUpKeyMappings();
		}
		else{
			

			if(isHost){
				try {
					//System.out.println("making connect");
					//Server.main(null);
					ser = new Server();
					Thread serThread = new Thread(ser);
					serThread.start();
					System.out.println("Made server");
					serverMade = true;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			try {
				if(serverMade){
					self = new Client("10.141.40.192");
					Thread selfThread = new Thread(self);
					selfThread.start();
					tronList.get(0).setIP(self.getIP());
					///10.141.131.237
					tronList.get(1).setIP("/10.141.64.207");
					//tronList.get(2).setIP("/10.141.44.140");
					System.out.println("connected");
					sp.setUpMultiKeyMappings();
					
				//Client.main(null);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		sp.startGame();
	}


	
	public static void nextPanel2(){
		frame.remove(hp);
		frame.add(sp);
		sp.setBackground(Color.BLACK);
		sp.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.pack();
		frame.setVisible(true);
		
		sp.startGame();
		
	}
	public static void nextPanel3(){
		frame.remove(cp);
		frame.add(sp);
		sp.setBackground(Color.BLACK);
		sp.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.pack();
		frame.setVisible(true);
		
		sp.startGame();
	}
	public static void nextPanel4(){
		hp = new HostPanel();
		frame.remove(p);
		frame.add(hp);
		hp.setBackground(Color.BLACK);
		hp.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.pack();
		frame.setVisible(true);
		
	}
	public static void nextPanel5(){
		cp = new ClientPanel();
		frame.remove(p);
		frame.add(cp);
		cp.setBackground(Color.BLACK);
		cp.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.pack();
		frame.setVisible(true);
	}
	public static void nextPanel6(){
		frame.remove(p);
		frame.add(sp);
		sp.setBackground(Color.BLACK);
		sp.addCycles();
		sp.setPreferredSize(new Dimension(screenLength, screenHeight));
		frame.pack();
		frame.setVisible(true);
		sp.setUpKeyMappings();
		sp.startGame();
	}
	
	public static void print(String s){
		System.out.println(s);
	}
	
	public TronPanel() {
		String fileName = "spacegif1.gif";
		File file = new File(fileName);

		URL url = null;

		try {
			url = new URL(file.toURL(), fileName);
			System.out.println(url);
		} catch (MalformedURLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		System.out.println(url);
		ImageIcon icon = new ImageIcon(url); 
		JLabel gif = new JLabel(icon) {
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				//paintComponent1(g);
			}
		}; 

		try {

			Image img =  icon.getImage().getScaledInstance(screenLength ,this.screenHeight, Image.SCALE_FAST);

			icon =new ImageIcon(img);

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		try {
			// Set System L&F
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.label = new JLabel(icon) {
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				sp.paintComponent(g);
			}
		};
		this.setLayout(null);
		label.setBounds(0, 0, screenLength, screenHeight);

		//space

		//	        try {
		//				logo = ImageIO.read(new File("tronLogo.png"));
		//			} catch (IOException e) {
		//				// TODO Auto-generated catch block
		//				e.printStackTrace();
		//			}


	}
	public void setUpMultiKeyMappings() {
		// TODO Auto-generated method stub
		this.getInputMap().put(KeyStroke.getKeyStroke("B"), "boost");
		this.getActionMap().put("boost", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				self.setActionMessage("BOOST");
				System.out.println("tried to boost");
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "space");
		this.getActionMap().put("space", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(isHost)
					self.setActionMessage("RESTART");

			}
		});
		this.getInputMap().put(KeyStroke.getKeyStroke("LEFT"), "left");
		this.getActionMap().put("left", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				self.setActionMessage("W");
				System.out.println("tried to left");
				//System.out.println("Left");
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("RIGHT"), "right");
		this.getActionMap().put("right", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				self.setActionMessage("E");
				System.out.println("tried to right");
				//System.out.println("Right");

			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "down");
		this.getActionMap().put("down", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				self.setActionMessage("S");
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("UP"), "up");
		this.getActionMap().put("up", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				self.setActionMessage("N");
			}
		});
		this.requestFocusInWindow();




	}
	public void setUpKeyMappings() {


		this.getInputMap().put(KeyStroke.getKeyStroke("T"), "t");
		this.getActionMap().put("t", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				timer.setDelay(timer.getDelay()/2);
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("P"), "p");
		this.getActionMap().put("p", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!allDone()) {
					if(timer.isRunning())
						timer.stop();
					else
						timer.start();
				}
			}
		});
		this.requestFocusInWindow();
		this.getInputMap().put(KeyStroke.getKeyStroke("B"), "boost");
		this.getActionMap().put("boost", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(int i=0; i<11;i++)
					if(!tronList.get(0).isDone()) {
						tronList.get(0).move();		
						for(Tron t1: tronList)
							if(!tronList.get(0).equals(t1))
								if (!tronList.get(0).boundsCheck(t1, screenLength, screenHeight)) {
									tronList.get(0).setDone(true);
									for(Tron t2: tronList)
										if(!t2.isDone())
											t2.incScore();
								}
					}
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("SPACE"), "space");
		this.getActionMap().put("space", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(Tron t: tronList)
					t.restart();
				timer.setDelay(t);
				timer.start();
				int a=obstacle.incLevel();			
				if(a==6) {
					for(Tron t: tronList)
						if(!t.isHuman())
							if(t.getAi().getDif()<6) {
								t.getAi().setDif(t.getAi().getDif() + 1);
								System.out.println(t.getAi().getDif());
							}
				}


			}
		});

		this.getInputMap().put(KeyStroke.getKeyStroke("LEFT"), "left");
		this.getActionMap().put("left", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!tronList.get(0).isDone()) {
					if (tronList.get(0).getDir() != Tron.Direction.E)
						tronList.get(0).setDir(Tron.Direction.W);
				}
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("RIGHT"), "right");
		this.getActionMap().put("right", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!tronList.get(0).isDone()) {
					if (tronList.get(0).getDir() != Tron.Direction.W)
						tronList.get(0).setDir(Tron.Direction.E);
				}
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("DOWN"), "down");
		this.getActionMap().put("down", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!tronList.get(0).isDone()) {
					if (tronList.get(0).getDir() != Tron.Direction.N)
						tronList.get(0).setDir(Tron.Direction.S);
				}
			}
		});
		this.requestFocusInWindow();

		this.getInputMap().put(KeyStroke.getKeyStroke("UP"), "up");
		this.getActionMap().put("up", new AbstractAction() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!tronList.get(0).isDone()) {
					if (tronList.get(0).getDir() != Tron.Direction.S)
						tronList.get(0).setDir(Tron.Direction.N);
				}
			}
		});
		this.requestFocusInWindow();

		if(is2PlayerLocal) {
			this.getInputMap().put(KeyStroke.getKeyStroke("A"), "a");
			this.getActionMap().put("a", new AbstractAction() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (tronList.get(1).getDir() != Tron.Direction.E)
						tronList.get(1).setDir(Tron.Direction.W);

				}
			});
			this.requestFocusInWindow();

			this.getInputMap().put(KeyStroke.getKeyStroke("D"), "d");
			this.getActionMap().put("d", new AbstractAction() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (tronList.get(1).getDir() != Tron.Direction.W)
						tronList.get(1).setDir(Tron.Direction.E);

				}
			});
			this.requestFocusInWindow();
			this.getInputMap().put(KeyStroke.getKeyStroke("S"), "s");
			this.getActionMap().put("s", new AbstractAction() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (tronList.get(1).getDir() != Tron.Direction.N)
						tronList.get(1).setDir(Tron.Direction.S);
				}
			});
			this.requestFocusInWindow();
			this.getInputMap().put(KeyStroke.getKeyStroke("W"), "w");
			this.getActionMap().put("w", new AbstractAction() {

				@Override
				public void actionPerformed(ActionEvent e) {
					if (tronList.get(1).getDir() != Tron.Direction.S)
						tronList.get(1).setDir(Tron.Direction.N);
				}
			});
			this.requestFocusInWindow();
		}

	}

	public void startGame() {
		frame.add(label);
		timer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				tick();
			}

		});
		timer.start();
	}

	protected void tick() {
		for (Tron t : tronList)
			if (!t.isDone()) {
				if (trapPlayer(t) && !t.isHuman() && t.getAi().getDif() == 5) {
					for (int i = 0; i < 4; i++) {
						t.move();
					}
				}
				while (trapPlayer(t) && !t.isHuman() && t.getAi().getDif() == 6) {
					t.move();
					random = true;
				}
				if (random) {
					t.move();
					random = false;
				}
				t.move();
			}
		for (Tron t : tronList)
			if (!t.isDone() && !t.isObstacle())
				for (Tron t1 : tronList)
					if (!t.equals(t1))
						if (!t.boundsCheck(t1, screenLength, screenHeight)) {
							t.setDone(true);
							for (Tron t2 : tronList)
								if (!t2.isDone())
									t2.incScore();
						}
		if (allDone())
			timer.stop();
		frame.repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
		board.draw(g);
		for(Tron t: tronList)
			t.draw(g);
		int playnum=1;
		g.setColor(Color.RED);
		for(Tron t: tronList) {
			if(!t.isObstacle()) {
				g.drawString("Player "+ playnum+" Score: " + tronList.get(playnum-1).getScore(), ((screenLength/tronList.size())-10)*(playnum-1), 50);
				playnum++;
			}
		}
		if(allDone()) {
			String s="WINNERS:";
			int c=1;
			for(Tron t: tronList) {
				if(!t.isDone())
					s+=" Player "+c;
				c++;
			}
			g.setColor(Color.WHITE);
			g.drawString(s, screenLength/2-73, screenHeight-50);
			g.drawString("PRESS SPACE TO CONTINUE", screenLength/2-73, screenHeight-100);
		}
	}

	public static int distinfront(int[] is, Tron.Direction dir) {
		// TODO Auto-generated method stub
		int dist = 0;
		//to add: special case for other tron heading at you
		if(dir==Tron.Direction.N) {
			is[1]-=w;
			while(isClear(is)) {
				dist++;
				is[1]-=w;
			}
		}
		else if(dir==Tron.Direction.E) {
			is[0]+=w;
			while(isClear(is)) {
				dist++;
				is[0]+=w;
			}
		}

		else if(dir==Tron.Direction.S) {
			is[1]+=w;
			while(isClear(is)) {
				dist++;
				is[1]+=w;
			}

		}

		else{
			is[0]-=w;
			while(isClear(is)) {
				dist++;
				is[0]-=w;
			}
		}
		return dist;
	}

	private static boolean isClear(int[] is) {
		// TODO Auto-generated method stub

		if(is[0]<0||is[1]<0|| is[0] > screenLength-w || is[1] > screenHeight-2*w)
			return false;
		for(Tron t: tronList)
			for (int i = 0; i < t.s.size() - 1; i++) {
				if (is[0] == t.s.get(i).getX() && is[1] == t.s.get(i).getY()) {
					return false;
				}
			}
		return true;
	}
	public static Tron.Direction farDistToOthers(int[] is, Tron.Direction dir) {
		int[] temp = new int[2];
		int dist = 0;
		int smallDist = 0;
		int index = 0;
		for (int i = 0; i < 2; i++) {
			Tron t = tronList.get(i);
			temp[0] = t.s.get(t.s.size() - 1).getX();
			temp[1] = t.s.get(t.s.size() - 1).getY();
			double d = Math.sqrt(Math.pow(temp[0] - is[0], 2) + Math.pow(temp[1] - is[1], 2));
			dist = (int) d;
			if (dist != 0)
				if (dist > smallDist) {
					smallDist = dist;
					index = i;
				}
		}
		Tron t = tronList.get(index);
		int x = t.s.get(t.s.size() - 1).getX();
		int y = t.s.get(t.s.size() - 1).getY();
		int dist1 = 0;
		int dist2 = 0;
		int xr;
		int xl;
		int yr;
		int yl;
		if (dir == Tron.Direction.N) {
			xr = is[0] + w;
			xl = is[0] - w;
			if (isClear(new int[] { xr, is[1] })) {
				double d = Math.sqrt(Math.pow(xr - x, 2) + Math.pow(is[1] - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 0;
			}
			if (isClear(new int[] { xl, is[1] })) {
				double e = Math.sqrt(Math.pow(xl - x, 2) + Math.pow(is[1] - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 0;
			}
			if (!isClear(new int[] { is[0], is[1] - w })) {
				smallDist = 0;
			}
			if (dist1 > smallDist && dist1 > dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 > smallDist) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}

		} else if (dir == Tron.Direction.E) {
			yr = is[1] + w;
			yl = is[1] - w;
			if (isClear(new int[] { is[0], yr })) {
				double d = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yr - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 0;
			}
			if (isClear(new int[] { is[0], yl })) {
				double e = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yl - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 0;
			}
			if (!isClear(new int[] { is[0] + w, is[1] })) {
				smallDist = 0;
			}
			if (dist1 > smallDist && dist1 > dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 > smallDist) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}
		}

		else if (dir == Tron.Direction.S) {
			xr = is[0] - w;
			xl = is[0] + w;
			if (isClear(new int[] { xr, is[1] })) {
				double d = Math.sqrt(Math.pow(xr - x, 2) + Math.pow(is[1] - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 0;
			}
			if (isClear(new int[] { xl, is[1] })) {
				double e = Math.sqrt(Math.pow(xl - x, 2) + Math.pow(is[1] - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 0;
			}
			if (!isClear(new int[] { is[0], is[1] + w })) {
				smallDist = 0;
			}
			if (dist1 > smallDist && dist1 > dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 > smallDist) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}
		}

		else {
			yr = is[1] - w;
			yl = is[1] + w;
			if (isClear(new int[] { is[0], yr })) {
				double d = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yr - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 0;
			}
			if (isClear(new int[] { is[0], yl })) {
				double e = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yl - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 0;
			}
			if (!isClear(new int[] { is[0] - w, is[1] })) {
				smallDist = 0;
			}
			if (dist1 > smallDist && dist1 > dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 > smallDist) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}
		}
	}
	
	public static Tron.Direction distToOthers(int[] is, Tron.Direction dir) {
		int[] temp = new int[2];
		int dist = 0;
		int smallDist = 10000;
		int index = 0;
		for (int i = 0; i < tronList.size() - 2; i++) {
			Tron t = tronList.get(i);
			temp[0] = t.s.get(t.s.size() - 1).getX();
			temp[1] = t.s.get(t.s.size() - 1).getY();
			double d = Math.sqrt(Math.pow(temp[0] - is[0], 2) + Math.pow(temp[1] - is[1], 2));
			dist = (int) d;
			if (dist != 0)
				if (dist < smallDist) {
					smallDist = dist;
					index = i;
				}
		}
		Tron t = tronList.get(index);
		int x = t.s.get(t.s.size() - 1).getX();
		int y = t.s.get(t.s.size() - 1).getY();
		int dist1 = 0;
		int dist2 = 0;
		int xr;
		int xl;
		int yr;
		int yl;
		if (dir == Tron.Direction.N) {
			xr = is[0] + w;
			xl = is[0] - w;
			if (isClear(new int[] { xr, is[1] })) {
				double d = Math.sqrt(Math.pow(xr - x, 2) + Math.pow(is[1] - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 100000;
			}
			if (isClear(new int[] { xl, is[1] })) {
				double e = Math.sqrt(Math.pow(xl - x, 2) + Math.pow(is[1] - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 100000;
			}
			if (!isClear(new int[] { is[0], is[1] - w })) {
				smallDist = 100000;
			}
			if (dist1 < smallDist && dist1 != 0 && dist1 < dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 < smallDist && dist2 != 0) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}

		} else if (dir == Tron.Direction.E) {
			yr = is[1] + w;
			yl = is[1] - w;
			if (isClear(new int[] { is[0], yr })) {
				double d = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yr - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 100000;
			}
			if (isClear(new int[] { is[0], yl })) {
				double e = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yl - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 100000;
			}
			if (!isClear(new int[] { is[0] + w, is[1] })) {
				smallDist = 100000;
			}
			if (dist1 < smallDist && dist1 != 0 && dist1 < dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 < smallDist && dist2 != 0) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}
		}

		else if (dir == Tron.Direction.S) {
			xr = is[0] - w;
			xl = is[0] + w;
			if (isClear(new int[] { xr, is[1] })) {
				double d = Math.sqrt(Math.pow(xr - x, 2) + Math.pow(is[1] - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 100000;
			}
			if (isClear(new int[] { xl, is[1] })) {
				double e = Math.sqrt(Math.pow(xl - x, 2) + Math.pow(is[1] - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 100000;
			}
			if (!isClear(new int[] { is[0], is[1] + w })) {
				smallDist = 100000;
			}
			if (dist1 < smallDist && dist1 != 0 && dist1 < dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 < smallDist && dist2 != 0) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}
		}

		else {
			yr = is[1] - w;
			yl = is[1] + w;
			if (isClear(new int[] { is[0], yr })) {
				double d = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yr - y, 2));
				dist1 = (int) d;
			} else {
				dist1 = 100000;
			}
			if (isClear(new int[] { is[0], yl })) {
				double e = Math.sqrt(Math.pow(is[0] - x, 2) + Math.pow(yl - y, 2));
				dist2 = (int) e;
			} else {
				dist2 = 100000;
			}
			if (!isClear(new int[] { is[0] - w, is[1] })) {
				smallDist = 100000;
			}
			if (dist1 < smallDist && dist1 != 0 && dist1 < dist2) {
				return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
			} else if (dist2 < smallDist && dist2 != 0) {
				return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
			} else {
				return dir;
			}
		}
	}
	
	public static Tron.Direction checkDeadEnd(int[] is, Tron.Direction dir) {
		int a;
		int b;
		int c;
		if (dir == Tron.Direction.N) {
			is[1] -= w;
			a = distinfront(new int[] { is[0], is[1] }, dir);
			b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
			c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
			is[1] += w;
			if (a == 0 && b == 0 && c == 0) {
				a = distinfront(new int[] { is[0], is[1] }, dir);
				b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
				c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
				if (distToOthers(is, dir) == dir) {
					if (b > c) {
						return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
					} else {
						return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
					}
				}
				return distToOthers(is, dir);
			}
		} else if (dir == Tron.Direction.E) {
			is[0] += w;
			a = distinfront(new int[] { is[0], is[1] }, dir);
			b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
			c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
			is[0] -= w;
			if (a == 0 && b == 0 && c == 0) {
				a = distinfront(new int[] { is[0], is[1] }, dir);
				b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
				c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
				if (distToOthers(is, dir) == dir) {
					if (b > c) {
						return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
					} else {
						return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
					}
				}
				return distToOthers(is, dir);
			}
		} else if (dir == Tron.Direction.S) {
			is[1] += w;
			a = distinfront(new int[] { is[0], is[1] }, dir);
			b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
			c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
			is[1] -= w;
			if (a == 0 && b == 0 && c == 0) {
				a = distinfront(new int[] { is[0], is[1] }, dir);
				b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
				c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
				if (distToOthers(is, dir) == dir) {
					if (b > c) {
						return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
					} else {
						return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
					}
				}
				return distToOthers(is, dir);
			}
		} else {
			is[0] -= w;
			a = distinfront(new int[] { is[0], is[1] }, dir);
			b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
			c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
			is[0] += w;
			if (a == 0 && b == 0 && c == 0) {
				a = distinfront(new int[] { is[0], is[1] }, dir);
				b = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 1) % 4]);
				c = distinfront(new int[] { is[0], is[1] }, Tron.Direction.values()[(dir.ordinal() + 3) % 4]);
				if (distToOthers(is, dir) == dir) {
					if (b > c) {
						return Tron.Direction.values()[(dir.ordinal() + 1) % 4];
					} else {
						return Tron.Direction.values()[(dir.ordinal() + 3) % 4];
					}
				}
				return distToOthers(is, dir);
			}
		}
		return distToOthers(is, dir);
	}
	
	private static boolean trapPlayer(Tron tr) {
		Tron t = tronList.get(0);

		int x = t.s.get(t.s.size() - 1).getX();
		int y = t.s.get(t.s.size() - 1).getY();
		int x1 = tr.s.get(tr.s.size() - 1).getX();
		int y1 = tr.s.get(tr.s.size() - 1).getY();
		if (x - x1 == w && t.getDir() == tr.getDir() && !isClear(new int[] { x1 + w, y1 })) {
			return true;
		} else if (x - x1 == -w && t.getDir() == tr.getDir() && !isClear(new int[] { x1 - w, y1 })) {
			return true;
		} else if (y - y1 == w && t.getDir() == tr.getDir() && !isClear(new int[] { x1, y1 + w })) {
			return true;
		} else if (y - y1 == -w && t.getDir() == tr.getDir() && !isClear(new int[] { x1, y1 - w })) {
			return true;
		}

		return false;
	}
	
	public boolean allDone() {
		// TODO Auto-generated method stub
		int numDone=0;
		for(Tron t: tronList)
			if(t.isDone())
				numDone++;
		return numDone+1>=tronList.size();
	}

	public static int getW() {
		return w;
	}

	public static void setW(int w) {
		TronPanel.w = w;
	}
	public static void moveTron(String ip, String dir) {
		// TODO Auto-generated method stub
		for(int i =0; i< tronList.size();i++){
			if(tronList.get(i).getIP()!=null&&tronList.get(i).getIP().equals(ip)){
				//Tron.Direction d = Tron.Direction.valueOf(dir);
				//int across;
				
				tronList.get(i).changeDir(Tron.Direction.valueOf(dir));
				break;
			}
		}
	}
	public static void restart() {
		// TODO Auto-generated method stub
		for(Tron t: tronList)
			t.restart();
		timer.setDelay(t);
		timer.start();
	}
}
