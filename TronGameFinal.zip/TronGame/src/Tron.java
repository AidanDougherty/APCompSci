import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.UIManager;

public class Tron {

	public enum Direction {
		N, E, S, W

	};

	private String ip;
	private Direction dir;
	private Direction sdir;
	public List<Segment> s = new ArrayList();
	private int size = TronPanel.getW();
	private int score = 0;
	private boolean isHuman;
	private AI ai;
	private boolean done = false;
	private static ArrayList<BufferedImage> cycles = new ArrayList<BufferedImage>();
	private boolean isObstacle = false;
	private int dif;

	public Tron(int x, int y, Direction dir, int diff) {
		try {
			for(Direction d: Direction.values()) {
				cycles.add(ImageIO.read(new File("blue_cycle_"+d.name()+".png")));
				cycles.add(ImageIO.read(new File("yellow_cycle_"+d.name()+".png")));
			}
		}
			catch(Exception e) {
				e.printStackTrace();
			}
		this.sdir=dir;
		this.dir=dir;
		s.add(new Segment(x, y));
		isHuman = diff==0;
		if(!isHuman)
			setAi(new AI(diff));
		dif = diff;
	}

	public void move() {
		if(!isHuman)
			dir = ai.getMove(new int[] {s.get(s.size()-1).x, s.get(s.size()-1).y}, dir);
		int h = size;
		int g = size;
		if (dir == Direction.N) {
			h = -size;
			g = 0;
		}
		if (dir == Direction.S) {
			h = size;
			g = 0;
		}
		if (dir == Direction.E) {
			g = size;
			h = 0;
		}
		if (dir == Direction.W) {
			g = -size;
			h = 0;
		}
		s.add(new Segment(s.get(s.size() - 1).getX() + g, s.get(s.size() - 1).getY() + h));
	}
	
	public void setIP(String s){
		ip =s;
		
	}
	public void changeDir(Tron.Direction d){
		if (d==Tron.Direction.E&&this.getDir()!=Tron.Direction.W)
			this.setDir(Tron.Direction.E);
		else if (d==Tron.Direction.W&&this.getDir()!=Tron.Direction.E)
			this.setDir(Tron.Direction.W);
		else if (d==Tron.Direction.N&&this.getDir()!=Tron.Direction.S)
			this.setDir(Tron.Direction.N);
		else if (d==Tron.Direction.S&&this.getDir()!=Tron.Direction.N)
			this.setDir(Tron.Direction.S);
	}
	public String getIP(){
		return ip;
	}
	

	public boolean boundsCheck(Tron t, int l, int h) {
		List<Segment> d = t.s;
		if (s.get(s.size() - 1).getX() < 0 || s.get(s.size() - 1).getY() < 0 || s.get(s.size() - 1).getX() > l-size
				|| s.get(s.size() - 1).getY() > h-2*size) {
			return false;
		}

		for (int i = 0; i < s.size()-1; i++) {
			if (s.get(s.size() - 1).getX() == s.get(i).getX())
				if (s.get(s.size() - 1).getY() == s.get(i).getY()) {
					return false;
				}
		}
		for (int i = 0; i < d.size(); i++) {
			if (s.get(s.size()-1).getX() == d.get(i).getX())
				if (s.get(s.size()-1).getY() == d.get(i).getY()) {
					if (i != d.size()-1)
					return false;
				}
		}
		return true;
	}

	public void restart() {
		for (int i = s.size() - 1; i > 0; i--) {
			s.remove(i);
		}
		dir=sdir;
		done=false;
	}

	public void setDir(Direction d) {
		dir = d;
	}

	public Direction getDir() {
		return dir;
	}

	public void draw(Graphics g) {
		if(sdir == Direction.E)
			g.setColor(Color.YELLOW);
		else if(sdir==Direction.W)
			g.setColor(Color.CYAN);
		else if(sdir==Direction.N)
			g.setColor(Color.GREEN);
		else
			g.setColor(Color.MAGENTA);
		for (Segment seg : s) {
			g.fillRect(seg.getX(), seg.getY(), size, size);
		}
		int h=3*size;
		if(dir.ordinal()%2==0)
			h=size;
		int place = 0;
		if(dir==Direction.E||dir==Direction.S)
			place = 1;
		int color=0;
		if(sdir==Direction.E)
			color=1;
		int specialCase=0;
		if(dir==Direction.S)
			specialCase=2*size;
		g.drawImage(cycles.get(color+dir.ordinal()*2), s.get(s.size()-1).x-(h-size)*place, s.get(s.size()-1).y-specialCase, h, 4*size-h, null);
			

	}

	public boolean isHuman() {
		return isHuman;
	}

	public void setHuman(boolean isHuman) {
		this.isHuman = isHuman;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}

	public void incScore() {
		// TODO Auto-generated method stub
		score++;
	}
	public boolean isObstacle() {
		return isObstacle;
	}

	public void setObstacle(boolean isObstacle) {
		this.isObstacle = isObstacle;
	}

	public AI getAi() {
		return ai;
	}

	public void setAi(AI ai) {
		this.ai = ai;
	}

	public int getDif() {
		// TODO Auto-generated method stub
		return dif;
	}

}
