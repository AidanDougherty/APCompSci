import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class ClientPanel extends JPanel{

	private JButton connect;
	private JTextField enterIP;
	
	
	public ClientPanel(){
		enterIP = new JTextField("Enter Host IP Here");
		
		enterIP.setHorizontalAlignment(JTextField.LEFT);
		enterIP.setBounds(1260/4,700/4, 1260/2, 700/8);
		connect = new JButton("Connect");
		connect.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//System.out.println("boop");
				System.out.println(enterIP.getText());
				TronPanel.clientConnect(enterIP.getText());
				TronPanel.nextPanel3();
				//TronPanel.nextPanel(connect.getText());
				
			
			}
		});
		this.add(enterIP);
		this.setLayout(null);
		connect.setBounds(1260/4,3*700/4, 1260/2, 700/8);
		connect.setBackground(Color.BLACK);
		connect.setFont(new Font(Font.SANS_SERIF, Font.ROMAN_BASELINE, 30));
		this.add(connect);
		this.setBackground(Color.BLACK);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
