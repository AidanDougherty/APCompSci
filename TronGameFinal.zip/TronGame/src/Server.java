import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.Scanner;

import javax.swing.Timer;

public class Server implements Runnable{
	static ServerSocket serverSocket;
	static Socket socket;
	static DataOutputStream output;
	private static boolean online;
	private static boolean waiting;
	static DataInputStream in;
	static Timer t;
	static String msg;
	static User[] users = new User[4];

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//t = new Timer(50, null);
		//48042
		serverSocket = new ServerSocket(48042);
		online = true;
		waiting = true;
		System.out.println("Sever made");
		while(online){
			socket = serverSocket.accept();
			//make new thread
			for(int i=0; i<4; i++){
				System.out.println("Client accepted: "+socket.getInetAddress());
				output = new DataOutputStream(socket.getOutputStream());
				in = new DataInputStream(socket.getInputStream());
				if(users[i]==null){
					users[i] = new User(output, in, users);
					Thread thread = new Thread(users[i]);
					thread.start();
					break;
				}
			}
		}


		//output.writeUTF("BITCONEEEEEEEECT");

		//		t.addActionListener(new ActionListener() {
		//
		//			@Override
		//			public void actionPerformed(ActionEvent arg0) {
		//				
		//				tick();
		//			}
		//
		//		});
		//		t.start();
//		while(online){
//			Scanner inputDevice=new Scanner(System.in);
//			String s = inputDevice.nextLine();
//			output.writeUTF(s);
//			//System.out.println("SER: "+s);
//			//			if(s.equals("SYSTEM.EXIT")){
//			//				online = false;
//			//			}
//
//
//		}
	}
	protected static void tick(){
		try {
			//System.out.println("tick");
			msg = in.readUTF();
			if(msg!=null)
				System.out.println("CL: "+msg);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}

	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			serverSocket = new ServerSocket(48042);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		online = true;
		waiting = true;
		System.out.println("Sever made");
		while(online){
			try {
				socket = serverSocket.accept();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//make new thread
			for(int i=0; i<4; i++){
				System.out.println("Client accepted: "+socket.getInetAddress());
				try{
				output = new DataOutputStream(socket.getOutputStream());
				in = new DataInputStream(socket.getInputStream());
				}catch (Exception e){
					e.printStackTrace();
				}
				if(users[i]==null){
					users[i] = new User(output, in, users);
					Thread thread = new Thread(users[i]);
					thread.start();
					break;
				}
			}
		}
	}
	

}
